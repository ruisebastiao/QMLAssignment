#include "menustyle.h"
#include <QMenu>

MenuStyle::MenuStyle()
{

}
